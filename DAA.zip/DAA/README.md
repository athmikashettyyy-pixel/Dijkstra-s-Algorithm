# Dijkstra's Algorithm — Full-Stack Visualizer

Interactive shortest-path visualizer with a Python/Flask backend and a plain-JS canvas frontend.

---

## Project Structure

```
dijkstra/
├── backend/
│   ├── app.py           # Flask REST API (port 5000)
│   ├── dijkstra.py      # Core algorithm + step tracer
│   └── requirements.txt
└── frontend/
    ├── index.html       # Main page
    ├── server.py        # Static file server (port 8000)
    └── static/
        ├── css/
        │   └── style.css
        └── js/
            └── main.js
```

---

## Setup & Run

### 1. Backend (Python / Flask — port 5000)

```bash
cd backend
pip install -r requirements.txt
python app.py
```

You'll see:
```
* Running on http://0.0.0.0:5000
```

### 2. Frontend (JS — port 8000)

Open a second terminal:

```bash
cd frontend
python server.py
```

Then open your browser at: **http://localhost:8000**

---

## API Endpoints

| Method | Endpoint        | Description                          |
|--------|-----------------|--------------------------------------|
| GET    | `/api/health`   | Health check                         |
| GET    | `/api/presets`  | Returns all built-in graph presets   |
| POST   | `/api/solve`    | Run Dijkstra on a given graph        |
| POST   | `/api/custom`   | Run Dijkstra on a user-defined graph |

### POST `/api/solve` — Request Body

```json
{
  "graph": {
    "A": { "B": 4, "C": 2 },
    "B": { "A": 4, "C": 5, "D": 10 },
    "C": { "A": 2, "B": 5, "E": 3 },
    "D": { "B": 10, "E": 4, "F": 11 },
    "E": { "C": 3, "D": 4, "F": 8 },
    "F": { "D": 11, "E": 8 }
  },
  "start": "A",
  "end": "F"
}
```

### POST `/api/solve` — Response

```json
{
  "path": ["A", "C", "E", "F"],
  "cost": 13,
  "all_distances": { "A": 0, "B": 9, "C": 2, "D": 9, "E": 5, "F": 13 },
  "steps": [
    {
      "visiting": "A",
      "distance": 0,
      "visited": ["A"],
      "distances": { "A": 0 },
      "neighbors_updated": [
        { "node": "B", "new_dist": 4 },
        { "node": "C", "new_dist": 2 }
      ]
    }
  ]
}
```

---

## Algorithm Overview

Dijkstra's algorithm (1959) finds the shortest path from a source node to all other nodes in a weighted graph with non-negative edge weights.

**Time Complexity:** O((V + E) log V) with a min-heap  
**Space Complexity:** O(V)

### Steps:
1. Initialize distances: source = 0, all others = ∞
2. Push source into a min-heap
3. Pop the minimum-distance unvisited node
4. For each neighbor, relax the edge (update if shorter path found)
5. Repeat until destination is reached or heap is empty
6. Reconstruct path by backtracking via `previous` pointers

---

## Graph Presets

| Preset   | Nodes | Use Case                        |
|----------|-------|---------------------------------|
| City     | 6     | GPS / urban navigation          |
| Network  | 5     | Computer network routing        |
| Delivery | 7     | Last-mile delivery optimization |

---

## Extending with Custom Graphs

POST to `/api/custom` with your own adjacency dictionary. The graph must be:
- Undirected or directed (both supported)
- Non-negative edge weights only
- All nodes referenced in edges must be top-level keys
