const API = "http://localhost:5000/api";

// ─── State ───────────────────────────────────────────────────────────────────
let state = {
  presets: {},
  activePreset: "city",
  graph: {},
  nodes: [],
  start: "",
  end: "",
  result: null,
  animStep: 0,
  animTimer: null,
  nodePositions: {},
};

// ─── Canvas Setup ────────────────────────────────────────────────────────────
const canvas = document.getElementById("graphCanvas");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  const rect = canvas.parentElement.getBoundingClientRect();
  canvas.width = rect.width * devicePixelRatio;
  canvas.height = rect.height * devicePixelRatio;
  canvas.style.width = rect.width + "px";
  canvas.style.height = rect.height + "px";
  ctx.scale(devicePixelRatio, devicePixelRatio);
  layoutNodes();
  drawGraph();
}

// ─── Node Layout ─────────────────────────────────────────────────────────────
function layoutNodes() {
  const nodes = state.nodes;
  if (!nodes.length) return;

  const W = canvas.width / devicePixelRatio;
  const H = canvas.height / devicePixelRatio;
  const cx = W / 2, cy = H / 2;
  const r = Math.min(W, H) * 0.36;

  state.nodePositions = {};

  if (nodes.length === 1) {
    state.nodePositions[nodes[0]] = { x: cx, y: cy };
    return;
  }

  // Circular layout with slight randomization per node count
  nodes.forEach((node, i) => {
    const angle = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
    state.nodePositions[node] = {
      x: cx + Math.cos(angle) * r,
      y: cy + Math.sin(angle) * r,
    };
  });
}

// ─── Drawing ─────────────────────────────────────────────────────────────────
const COLORS = {
  bg: "#060a10",
  border: "#1e3a5f",
  accent: "#00d4ff",
  accent2: "#ff6b35",
  accent3: "#39ff14",
  text: "#cce8ff",
  muted: "#5a8ab0",
  nodeDefault: "#0d1520",
  visited: "rgba(57,255,20,0.15)",
  pathNode: "rgba(255,107,53,0.2)",
  current: "rgba(0,212,255,0.15)",
};

function getNodeState(node) {
  const { result, animStep } = state;
  if (!result) return "default";

  const steps = result.steps;
  const pathSet = new Set(result.path);
  const visitedSoFar = new Set();

  for (let i = 0; i <= Math.min(animStep, steps.length - 1); i++) {
    steps[i].visited.forEach((v) => visitedSoFar.add(v));
  }

  const currentNode = animStep < steps.length ? steps[animStep].visiting : null;

  if (node === currentNode) return "current";
  if (animStep >= steps.length && pathSet.has(node)) return "path";
  if (visitedSoFar.has(node)) return "visited";
  return "default";
}

function drawEdge(fromPos, toPos, weight, highlighted, onPath) {
  const { x: x1, y: y1 } = fromPos;
  const { x: x2, y: y2 } = toPos;

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);

  if (onPath) {
    ctx.strokeStyle = COLORS.accent2;
    ctx.lineWidth = 3;
    ctx.shadowBlur = 12;
    ctx.shadowColor = COLORS.accent2;
  } else if (highlighted) {
    ctx.strokeStyle = COLORS.accent;
    ctx.lineWidth = 1.5;
    ctx.shadowBlur = 6;
    ctx.shadowColor = COLORS.accent;
  } else {
    ctx.strokeStyle = COLORS.border;
    ctx.lineWidth = 1;
    ctx.shadowBlur = 0;
  }

  ctx.stroke();
  ctx.shadowBlur = 0;

  // Weight label
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const offset = 14;

  ctx.save();
  ctx.translate(mx + Math.sin(angle) * offset, my - Math.cos(angle) * offset);
  ctx.font = "bold 10px 'Space Mono'";
  ctx.fillStyle = onPath ? COLORS.accent2 : COLORS.muted;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(weight, 0, 0);
  ctx.restore();
}

function drawNode(node, pos) {
  const nodeState = getNodeState(node);
  const isStart = node === state.start;
  const isEnd = node === state.end;
  const R = 26;

  let fillColor, strokeColor, glow;

  if (isStart) {
    fillColor = "rgba(57,255,20,0.2)";
    strokeColor = COLORS.accent3;
    glow = COLORS.accent3;
  } else if (isEnd) {
    fillColor = "rgba(255,68,68,0.2)";
    strokeColor = "#ff4444";
    glow = "#ff4444";
  } else if (nodeState === "current") {
    fillColor = COLORS.current;
    strokeColor = COLORS.accent;
    glow = COLORS.accent;
  } else if (nodeState === "path") {
    fillColor = COLORS.pathNode;
    strokeColor = COLORS.accent2;
    glow = COLORS.accent2;
  } else if (nodeState === "visited") {
    fillColor = COLORS.visited;
    strokeColor = COLORS.accent3;
    glow = null;
  } else {
    fillColor = COLORS.nodeDefault;
    strokeColor = COLORS.border;
    glow = null;
  }

  if (glow) {
    ctx.shadowBlur = 20;
    ctx.shadowColor = glow;
  }

  ctx.beginPath();
  ctx.arc(pos.x, pos.y, R, 0, Math.PI * 2);
  ctx.fillStyle = fillColor;
  ctx.fill();
  ctx.strokeStyle = strokeColor;
  ctx.lineWidth = glow ? 2 : 1;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Distance label
  const dist = state.result?.all_distances?.[node];
  if (dist !== undefined && state.animStep >= 0) {
    ctx.font = "bold 9px 'Space Mono'";
    ctx.fillStyle = COLORS.accent;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(dist, pos.x, pos.y - R - 10);
  }

  // Node name
  ctx.font = "bold 10px 'Space Mono'";
  ctx.fillStyle = COLORS.text;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const label = node.length > 10 ? node.substring(0, 9) + "…" : node;
  ctx.fillText(label, pos.x, pos.y);

  // Start/End badge
  if (isStart || isEnd) {
    ctx.font = "7px 'Space Mono'";
    ctx.fillStyle = isStart ? COLORS.accent3 : "#ff4444";
    ctx.fillText(isStart ? "START" : "END", pos.x, pos.y + R + 10);
  }
}

function drawGraph() {
  const W = canvas.width / devicePixelRatio;
  const H = canvas.height / devicePixelRatio;
  ctx.clearRect(0, 0, W, H);

  if (!state.nodes.length) {
    ctx.font = "14px 'Space Mono'";
    ctx.fillStyle = COLORS.muted;
    ctx.textAlign = "center";
    ctx.fillText("Select a preset and click RUN ALGORITHM", W / 2, H / 2);
    return;
  }

  const pathSet = new Set();
  const pathEdges = new Set();
  if (state.result && state.animStep >= state.result.steps.length) {
    state.result.path.forEach((n) => pathSet.add(n));
    for (let i = 0; i < state.result.path.length - 1; i++) {
      pathEdges.add(`${state.result.path[i]}->${state.result.path[i + 1]}`);
      pathEdges.add(`${state.result.path[i + 1]}->${state.result.path[i]}`);
    }
  }

  // Highlight edges from current step
  const currentVisiting = state.result?.steps?.[state.animStep]?.visiting;

  // Draw edges
  const drawn = new Set();
  for (const [from, neighbors] of Object.entries(state.graph)) {
    for (const [to, weight] of Object.entries(neighbors)) {
      const key = [from, to].sort().join("|");
      if (drawn.has(key)) continue;
      drawn.add(key);

      const fromPos = state.nodePositions[from];
      const toPos = state.nodePositions[to];
      if (!fromPos || !toPos) continue;

      const onPath = pathEdges.has(`${from}->${to}`);
      const highlighted = from === currentVisiting || to === currentVisiting;

      drawEdge(fromPos, toPos, weight, highlighted, onPath);
    }
  }

  // Draw nodes
  for (const node of state.nodes) {
    const pos = state.nodePositions[node];
    if (pos) drawNode(node, pos);
  }
}

// ─── Animation ───────────────────────────────────────────────────────────────
function animateSteps(steps) {
  clearInterval(state.animTimer);
  state.animStep = 0;

  const stepItems = document.querySelectorAll(".step-item");

  state.animTimer = setInterval(() => {
    drawGraph();

    // Reveal step in sidebar
    if (state.animStep < stepItems.length) {
      stepItems[state.animStep].classList.add("visible");
    }

    state.animStep++;

    if (state.animStep > steps.length) {
      clearInterval(state.animTimer);
      drawGraph(); // Final draw with full path
    }
  }, 700);
}

// ─── API Calls ───────────────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const res = await fetch(`${API}/health`);
    const data = await res.json();
    if (data.status === "ok") {
      document.getElementById("statusDot").className = "dot connected";
      document.getElementById("statusText").textContent = "API CONNECTED";
    }
  } catch {
    document.getElementById("statusDot").className = "dot error";
    document.getElementById("statusText").textContent = "API OFFLINE";
  }
}

async function loadPresets() {
  try {
    const res = await fetch(`${API}/presets`);
    state.presets = await res.json();
    applyPreset("city");
  } catch (e) {
    showError("Cannot connect to backend. Start the Flask server on port 5000.");
  }
}

function applyPreset(name) {
  const preset = state.presets[name];
  if (!preset) return;

  state.activePreset = name;
  state.graph = preset.graph;
  state.nodes = preset.nodes;
  state.start = preset.start;
  state.end = preset.end;
  state.result = null;
  state.animStep = 0;
  clearInterval(state.animTimer);

  // Update UI
  document.querySelectorAll(".preset-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.preset === name);
  });

  populateSelects();
  layoutNodes();
  drawGraph();
  document.getElementById("resultPanel").classList.remove("show");
  document.getElementById("errorMsg").classList.remove("show");
  document.getElementById("stepsContainer").innerHTML = "";
}

function populateSelects() {
  const startSel = document.getElementById("startNode");
  const endSel = document.getElementById("endNode");

  [startSel, endSel].forEach((sel) => {
    sel.innerHTML = "";
    state.nodes.forEach((n) => {
      const opt = document.createElement("option");
      opt.value = n;
      opt.textContent = n;
      sel.appendChild(opt);
    });
  });

  startSel.value = state.start;
  endSel.value = state.end;
}

async function runAlgorithm() {
  const start = document.getElementById("startNode").value;
  const end = document.getElementById("endNode").value;
  state.start = start;
  state.end = end;

  const btn = document.getElementById("runBtn");
  btn.disabled = true;
  btn.innerHTML = '<span class="loading"></span> COMPUTING…';

  showError("");

  try {
    const res = await fetch(`${API}/solve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ graph: state.graph, start, end }),
    });

    const data = await res.json();

    if (!res.ok) {
      showError(data.error || "Unknown error");
      return;
    }

    state.result = data;
    renderResult(data);
    renderSteps(data.steps);
    animateSteps(data.steps);
  } catch (e) {
    showError("Could not reach backend. Is Flask running on port 5000?");
  } finally {
    btn.disabled = false;
    btn.textContent = "RUN ALGORITHM";
  }
}

function renderResult(data) {
  const panel = document.getElementById("resultPanel");
  panel.classList.add("show");

  document.getElementById("totalCost").textContent = data.cost;

  const pathContainer = document.getElementById("pathNodes");
  pathContainer.innerHTML = "";

  data.path.forEach((node, i) => {
    const span = document.createElement("span");
    span.className = "path-node";
    span.textContent = node;
    pathContainer.appendChild(span);

    if (i < data.path.length - 1) {
      const arrow = document.createElement("span");
      arrow.className = "path-arrow";
      arrow.textContent = "→";
      pathContainer.appendChild(arrow);
    }
  });
}

function renderSteps(steps) {
  const container = document.getElementById("stepsContainer");
  container.innerHTML = "";

  steps.forEach((step, i) => {
    const div = document.createElement("div");
    div.className = "step-item";

    let text = `<span class="visiting">▶ ${step.visiting}</span> | dist: ${step.distance}`;
    if (step.neighbors_updated.length) {
      const updates = step.neighbors_updated.map((u) => `${u.node}→${u.new_dist}`).join(", ");
      text += `<br><span class="updated">↳ updated: ${updates}</span>`;
    }

    div.innerHTML = text;
    container.appendChild(div);
  });
}

function showError(msg) {
  const el = document.getElementById("errorMsg");
  if (msg) {
    el.textContent = msg;
    el.classList.add("show");
  } else {
    el.classList.remove("show");
  }
}

// ─── Event Listeners ─────────────────────────────────────────────────────────
document.querySelectorAll(".preset-btn").forEach((btn) => {
  btn.addEventListener("click", () => applyPreset(btn.dataset.preset));
});

document.getElementById("runBtn").addEventListener("click", runAlgorithm);
document.getElementById("loadCustomBtn").addEventListener("click", () => {
  const input = document.getElementById("customGraphInput").value.trim();

  if (!input) {
    showError("Please enter graph edges.");
    return;
  }

  try {
    const graph = {};
    const nodeSet = new Set();

    const lines = input.split("\n");

    lines.forEach((line) => {
      const parts = line.split(",");

      if (parts.length !== 3) {
        throw new Error(`Invalid format: ${line}`);
      }

      const from = parts[0].trim();
      const to = parts[1].trim();
      const weight = Number(parts[2].trim());

      if (isNaN(weight)) {
        throw new Error(`Invalid weight in line: ${line}`);
      }

      if (!graph[from]) graph[from] = {};
      if (!graph[to]) graph[to] = {};

      graph[from][to] = weight;
      graph[to][from] = weight;

      nodeSet.add(from);
      nodeSet.add(to);
    });

    const nodes = Array.from(nodeSet);

    state.graph = graph;
    state.nodes = nodes;
    state.start = nodes[0];
    state.end = nodes[nodes.length - 1];
    state.result = null;
    state.animStep = 0;

    populateSelects();
    layoutNodes();
    drawGraph();

    showError("");

    alert("Custom graph loaded successfully!");

  } catch (err) {
    showError(err.message);
  }
});

window.addEventListener("resize", resizeCanvas);

// ─── Init ────────────────────────────────────────────────────────────────────
checkHealth();
loadPresets();
resizeCanvas();
