#!/usr/bin/env python3
"""
Simple HTTP server for the Dijkstra frontend.
Run this to serve the frontend on port 8000.
"""
import http.server
import socketserver
import os

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        # Allow frontend to call backend on different port
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def log_message(self, format, *args):
        print(f"[Frontend] {self.address_string()} - {format % args}")


if __name__ == "__main__":
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"✅ Frontend running at http://localhost:{PORT}")
        print("   Open your browser and go to the URL above.")
        httpd.serve_forever()
