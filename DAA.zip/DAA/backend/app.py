from flask import Flask, request, jsonify
from flask_cors import CORS
from dijkstra import dijkstra

app = Flask(__name__)
CORS(app)

# --- Sample Graphs ---

CITY_GRAPH = {
    "A (Start)": {"B": 4, "C": 2},
    "B": {"A (Start)": 4, "C": 5, "D": 10},
    "C": {"A (Start)": 2, "B": 5, "E": 3},
    "D": {"B": 10, "E": 4, "F (End)": 11},
    "E": {"C": 3, "D": 4, "F (End)": 8},
    "F (End)": {"D": 11, "E": 8},
}

NETWORK_GRAPH = {
    "Router-A": {"Router-B": 1, "Router-C": 4},
    "Router-B": {"Router-A": 1, "Router-C": 2, "Router-D": 5},
    "Router-C": {"Router-A": 4, "Router-B": 2, "Router-D": 1},
    "Router-D": {"Router-B": 5, "Router-C": 1, "Server": 3},
    "Server": {"Router-D": 3},
}

DELIVERY_GRAPH = {
    "Warehouse": {"Zone-1": 5, "Zone-2": 10},
    "Zone-1": {"Warehouse": 5, "Zone-3": 3, "Zone-4": 9},
    "Zone-2": {"Warehouse": 10, "Zone-4": 2, "Zone-5": 1},
    "Zone-3": {"Zone-1": 3, "Depot": 8},
    "Zone-4": {"Zone-1": 9, "Zone-2": 2, "Depot": 4},
    "Zone-5": {"Zone-2": 1, "Depot": 6},
    "Depot": {"Zone-3": 8, "Zone-4": 4, "Zone-5": 6},
}

PRESETS = {
    "city": CITY_GRAPH,
    "network": NETWORK_GRAPH,
    "delivery": DELIVERY_GRAPH,
}


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "message": "Dijkstra API running"})


@app.route("/api/presets", methods=["GET"])
def get_presets():
    result = {}
    for name, graph in PRESETS.items():
        nodes = list(graph.keys())
        result[name] = {
            "nodes": nodes,
            "start": nodes[0],
            "end": nodes[-1],
            "graph": graph,
        }
    return jsonify(result)


@app.route("/api/solve", methods=["POST"])
def solve():
    data = request.get_json()

    graph = data.get("graph")
    start = data.get("start")
    end = data.get("end")

    if not graph or not start or not end:
        return jsonify({"error": "Missing graph, start, or end"}), 400

    if start not in graph:
        return jsonify({"error": f"Start node '{start}' not in graph"}), 400
    if end not in graph:
        return jsonify({"error": f"End node '{end}' not in graph"}), 400

    path, cost, all_distances = dijkstra(graph, start, end)

    if path is None:
        return jsonify({"error": f"No path found from '{start}' to '{end}'"}), 404

    # Build step-by-step trace
    steps = _trace_steps(graph, start, end)

    return jsonify({
        "path": path,
        "cost": cost,
        "all_distances": {k: v for k, v in all_distances.items() if v != float('inf')},
        "steps": steps,
    })


def _trace_steps(graph, start, end):
    """Trace algorithm steps for visualization."""
    import heapq

    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    previous = {node: None for node in graph}
    visited = set()
    heap = [(0, start)]
    steps = []

    while heap:
        current_dist, current_node = heapq.heappop(heap)
        if current_node in visited:
            continue
        visited.add(current_node)

        step = {
            "visiting": current_node,
            "distance": current_dist,
            "visited": list(visited),
            "distances": {k: v for k, v in distances.items() if v != float('inf')},
        }

        neighbors_updated = []
        for neighbor, weight in graph[current_node].items():
            new_dist = current_dist + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                previous[neighbor] = current_node
                heapq.heappush(heap, (new_dist, neighbor))
                neighbors_updated.append({"node": neighbor, "new_dist": new_dist})

        step["neighbors_updated"] = neighbors_updated
        steps.append(step)

        if current_node == end:
            break

    return steps


@app.route("/api/custom", methods=["POST"])
def custom_graph():
    """Accept a user-defined graph."""
    data = request.get_json()
    graph = data.get("graph", {})
    start = data.get("start")
    end = data.get("end")

    if not graph or not start or not end:
        return jsonify({"error": "Provide graph, start, and end"}), 400

    path, cost, all_distances = dijkstra(graph, start, end)
    steps = _trace_steps(graph, start, end)

    if path is None:
        return jsonify({"error": "No path found"}), 404

    return jsonify({
        "path": path,
        "cost": cost,
        "all_distances": {k: v for k, v in all_distances.items() if v != float('inf')},
        "steps": steps,
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
