import heapq
from typing import Dict, List, Tuple, Optional


def dijkstra(graph: Dict[str, Dict[str, float]], start: str, end: str) -> Tuple[Optional[List[str]], float, Dict[str, float]]:
    """
    Dijkstra's Algorithm for shortest path.

    Args:
        graph: Adjacency dict {node: {neighbor: weight}}
        start: Starting node
        end: Destination node

    Returns:
        (path, total_cost, all_distances)
    """
    if start not in graph or end not in graph:
        return None, float('inf'), {}

    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    previous = {node: None for node in graph}
    visited = set()

    # Min-heap: (distance, node)
    heap = [(0, start)]

    while heap:
        current_dist, current_node = heapq.heappop(heap)

        if current_node in visited:
            continue
        visited.add(current_node)

        if current_node == end:
            break

        for neighbor, weight in graph[current_node].items():
            if neighbor not in distances:
                distances[neighbor] = float('inf')
                previous[neighbor] = None

            new_dist = current_dist + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                previous[neighbor] = current_node
                heapq.heappush(heap, (new_dist, neighbor))

    # Reconstruct path
    if distances[end] == float('inf'):
        return None, float('inf'), distances

    path = []
    node = end
    while node is not None:
        path.append(node)
        node = previous[node]
    path.reverse()

    return path, distances[end], distances
